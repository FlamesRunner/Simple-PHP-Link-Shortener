////////////////////////////
// LINK SHORTENER SCRIPT
///////////////////////////

Thank you for downloading my script! I hope it helps you out in some way.
To install it, simply import the SQL file using the command line or some web interface (e.g phpMyAdmin). Make sure the table is named linkTable.
Set the values in config.php as you wish. For example, you may add some advertising code to the footer variable.
Lastly, please make sure you rename htaccess in the directory a/ to .htaccess.

Good luck, and enjoy!